rootProject.name = "HyperionShader"

pluginManagement {
    repositories {
        maven { url = uri("https://maven.fabricmc.net/") }
        maven { url = uri("https://maven.neoforged.net/releases/") }
        gradlePluginPortal()
    }
}

include("common", "fabric")  // NeoForge module dropped (Fabric only)
